GDG ENSIA — ACCEPTANCE EMAILS

10 ready-to-personalize HTML templates and plain-text alternatives.

Replace every occurrence before sending:
{{first_name}} — recipient’s first name (HTML-escape in HTML).
{{next_step_text}} — real next-step instructions (HTML-escape in HTML).
{{next_step_url}} — real absolute HTTPS link (attribute-escape in HTML).

The images use absolute public HTTPS URLs hosted in the project’s GitHub Pages.
Keep the repository and Pages hosting available when sending these emails.

Suggested subjects are in departments.json. Nothing has been sent. No dates,
chat groups, deadlines or meetings were invented. No name injection or sending
code is included. Test a real message in your intended email clients before
sending to recipients; browser previews are not inbox-client certification.

Preview: https://ilyyeees.github.io/gdg-emails-regs/
Source: https://github.com/ilyyeees/gdg-emails-regs
